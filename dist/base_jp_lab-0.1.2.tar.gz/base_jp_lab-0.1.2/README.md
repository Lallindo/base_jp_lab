## base_jp_lab ##

Pacote, com as estruturas básicas, para produção de sistemas de automação para e-commerce na JauPesca.

Para instalar o pacote, utilize o código abaixo enquando na pasta do repositório:\
``` python -m pip install . ```
