## base_jp_lab ##

Pacote, com as estruturas basícas, para produção de sistemas de automação para e-commerce na JauPesca.
